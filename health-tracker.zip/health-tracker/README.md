# 🩺 Health Tracker

A minimal, numbers-first daily health logging app. Log in under 60 seconds, see trends in graphs.

## Features
- Daily log: weight, sleep hours + quality, energy, mood, food quality, portions, symptoms
- Trend charts: area/line/bar charts for all metrics
- 7 / 14 / 30 / 90 day windows
- Symptom frequency tracker
- Conflict-free: logging the same day twice just updates the entry

---

## Setup

### 1. Railway (Database)

1. Go to [railway.app](https://railway.app) → New Project → PostgreSQL
2. Copy the `DATABASE_URL` from the PostgreSQL service's **Connect** tab
3. Keep it handy for step 3

### 2. Clone & install

```bash
git clone <your-repo>
cd health-tracker
npm install
```

### 3. Environment

```bash
cp .env.example .env.local
# Edit .env.local and paste your DATABASE_URL
```

### 4. Migrate the database

```bash
npm run db:migrate
```

### 5. Run locally

```bash
npm run dev
# Open http://localhost:3000
```

---

## Deploy to Vercel

1. Push your repo to GitHub
2. Go to [vercel.com](https://vercel.com) → New Project → import your repo
3. In **Environment Variables**, add `DATABASE_URL` with your Railway URL
4. Deploy!

Vercel auto-detects Next.js. No extra config needed.

---

## Metrics logged

| Metric | Type | Range |
|---|---|---|
| Weight | Slider | 40–200 kg |
| Sleep hours | Slider | 2–12h (0.5 steps) |
| Sleep quality | Slider | 1–10 |
| Energy | Slider | 1–10 |
| Mood | Slider | 1–10 |
| Food quality | Slider | 1–10 |
| Portions | Slider | 1–5 |
| Symptoms | Multi-select | 10 common options |
| Notes | Text | Optional |

---

## Stack

- **Frontend/Backend**: Next.js 14 (App Router)
- **Database**: PostgreSQL via Railway
- **Charts**: Recharts
- **Deploy**: Vercel
- **Styling**: Tailwind CSS
