import { NextResponse } from 'next/server';
import { query } from '@/lib/db';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const days = parseInt(searchParams.get('days') || '30');

  const result = await query(
    `SELECT * FROM health_logs 
     WHERE logged_date >= CURRENT_DATE - INTERVAL '${days} days'
     ORDER BY logged_date ASC`
  );

  return NextResponse.json(result.rows);
}

export async function POST(request: Request) {
  const body = await request.json();
  const {
    logged_date,
    weight_kg,
    sleep_hours,
    sleep_quality,
    energy,
    mood,
    food_quality,
    portions,
    symptoms,
    notes,
  } = body;

  const result = await query(
    `INSERT INTO health_logs 
      (logged_date, weight_kg, sleep_hours, sleep_quality, energy, mood, food_quality, portions, symptoms, notes)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
     ON CONFLICT (logged_date) DO UPDATE SET
       weight_kg = EXCLUDED.weight_kg,
       sleep_hours = EXCLUDED.sleep_hours,
       sleep_quality = EXCLUDED.sleep_quality,
       energy = EXCLUDED.energy,
       mood = EXCLUDED.mood,
       food_quality = EXCLUDED.food_quality,
       portions = EXCLUDED.portions,
       symptoms = EXCLUDED.symptoms,
       notes = EXCLUDED.notes,
       updated_at = NOW()
     RETURNING *`,
    [logged_date, weight_kg, sleep_hours, sleep_quality, energy, mood, food_quality, portions, symptoms, notes]
  );

  return NextResponse.json(result.rows[0]);
}
