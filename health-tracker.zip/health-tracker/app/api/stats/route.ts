import { NextResponse } from 'next/server';
import { query } from '@/lib/db';

export async function GET() {
  const result = await query(`
    SELECT
      COUNT(*) AS total_entries,
      ROUND(AVG(weight_kg)::numeric, 1) AS avg_weight,
      MIN(weight_kg) AS min_weight,
      MAX(weight_kg) AS max_weight,
      ROUND(AVG(sleep_hours)::numeric, 1) AS avg_sleep,
      ROUND(AVG(sleep_quality)::numeric, 1) AS avg_sleep_quality,
      ROUND(AVG(energy)::numeric, 1) AS avg_energy,
      ROUND(AVG(mood)::numeric, 1) AS avg_mood,
      ROUND(AVG(food_quality)::numeric, 1) AS avg_food_quality,
      MIN(logged_date) AS first_log,
      MAX(logged_date) AS last_log
    FROM health_logs
    WHERE logged_date >= CURRENT_DATE - INTERVAL '30 days'
  `);

  // Most common symptoms
  const symptomsResult = await query(`
    SELECT unnest(symptoms) AS symptom, COUNT(*) AS count
    FROM health_logs
    WHERE logged_date >= CURRENT_DATE - INTERVAL '30 days'
      AND symptoms IS NOT NULL
    GROUP BY symptom
    ORDER BY count DESC
    LIMIT 5
  `);

  return NextResponse.json({
    summary: result.rows[0],
    top_symptoms: symptomsResult.rows,
  });
}
